package com.nik.shoppingcart.dao;

import com.nik.shoppingcart.model.UserOrder;

public interface UserOrderDAO {
	
	public void saveOrUpdate(UserOrder userOrder);

	
	

}
