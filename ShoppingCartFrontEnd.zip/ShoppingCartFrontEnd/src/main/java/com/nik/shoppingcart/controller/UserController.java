package com.nik.shoppingcart.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.nik.shoppingcart.dao.CartDAO;
import com.nik.shoppingcart.dao.ProductDAO;
import com.nik.shoppingcart.dao.UserDAO;
import com.nik.shoppingcart.model.Cart;
import com.nik.shoppingcart.model.Product;
import com.nik.shoppingcart.model.User;

@Controller
public class UserController {

	@Autowired
	UserDAO userDAO;

	@Autowired
	User user;

	@Autowired(required = true)
	private ProductDAO productDAO;
	@Autowired(required = true)
	private CartDAO cartDAO;

	@RequestMapping("/logout")
	public ModelAndView logout(HttpServletRequest request, HttpSession session) {

		List<Cart> cartItems = (List<Cart>) this.cartDAO.list();

		for (Cart item : cartItems) {
			int id = item.getId();
			cartDAO.delete(id);
		}

		ModelAndView mv = new ModelAndView("/Home");
		session.invalidate();
		session = request.getSession(true);
		mv.addObject("logoutMessage", "You are successfully logged out");
		mv.addObject("loggedOut", "true");

		return mv;
	}

	@RequestMapping("/productlist1")
	public ModelAndView user1(HttpServletRequest req, HttpServletResponse res) {
		org.springframework.security.core.userdetails.User user = (org.springframework.security.core.userdetails.User) SecurityContextHolder
				.getContext().getAuthentication().getPrincipal();
		String name = user.getUsername();
		req.getSession().setAttribute("username", name);
		ModelAndView mv = new ModelAndView("/productlist");
		mv.addObject("product", new Product());
		mv.addObject("productList", this.productDAO.list());
		return mv;
	}

	@RequestMapping("/userhome")
	public ModelAndView userhome() {
		ModelAndView mv = new ModelAndView("/Home2");
		mv.addObject("product", new Product());
		mv.addObject("productList", this.productDAO.list());
		return mv;
	}

	@RequestMapping("/admin1")
	public ModelAndView admin1() {
		ModelAndView mv = new ModelAndView("/AdminHome");

		return mv;
	}

}
